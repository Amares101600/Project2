#!/bin/bash

function user_details {
	echo "User Name: $(whoami)"
	echo "Home Directory: $HOME"
}

user_details
user_details

