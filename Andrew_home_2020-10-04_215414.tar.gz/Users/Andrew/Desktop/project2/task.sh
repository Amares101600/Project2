#!/bin/bash
pwd
cal
date
ls
